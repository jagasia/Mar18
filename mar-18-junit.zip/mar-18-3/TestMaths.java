import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)
public class TestMaths {
	int no1, no2;
	float expected;
	
	Mathematics aut=new Mathematics();
	
	public TestMaths(int no1, int no2, float expected)
	{
		this.no1=no1;
		this.no2=no2;
		this.expected=expected;
	}
	
	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testSum() {
//		int no1=2;
//		int no2=3;
		aut.setNo1(no1);
		aut.setNo2(no2);
//		float expected=no1+no2;
		
		aut.sum();
		float actual=aut.getResult();
		assertEquals(expected, actual,0);
		
	}
	
	@Parameterized.Parameters
	   public static Collection sumNumbers() {
	      return Arrays.asList(new Object[][] {
	         { 2, 3, 5 },
	         { 6, 3, 9 },
	         { 19, 1, 20 },
	         { 22, 1, 23 },
	         { 23, 1, 24 },
	         {1,2,3}
	      });
	   }


	/*
	 * @Test public final void testDifference() { fail("Not yet implemented"); //
	 * TODO }
	 * 
	 * @Test public final void testProduct() { fail("Not yet implemented"); // TODO
	 * }
	 * 
	 * @Test public final void testDivide() { fail("Not yet implemented"); // TODO }
	 */
}
