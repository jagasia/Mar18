package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import java.io.IOException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import jag.Mathematics;

public class MathematicsTest {

	private static Mathematics aut=new Mathematics();

	@BeforeClass
	public static void setup()
	{
		System.out.println("Before method");
		aut.setNo1(100);
		aut.setNo2(200);		
	}
	
	
	
	
	
	@Test
	@Ignore
	public void testSum3()
	{
		aut.sum();
		int actual = aut.getResult();
		assertEquals(300, actual);
	}
	
	@Test
	public void testSum1()
	{
		int no1=12;
		int no2=13;
		int expected=25;
		int actual=aut.sum(no1, no2);
		assertEquals(expected, actual);
	}
	
	@Test
	@Ignore
	public void testSum2()
	{
		int no1=12;
		int no2=13;
		int expected=25;
		int actual=aut.sum(no1, no2);
		assertEquals(expected, actual);
	}
	@Test
	public void testDifference()
	{
		int no1=12;
		int no2=13;
		int expected=-1;
		int actual=aut.difference(no1, no2);
		
		assertEquals(expected, actual);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testDivide1()
	{
		int no1=10;
		int no2=0;
		int expected=5;
		int actual=aut.divide(no1, no2);
		assertEquals(expected, actual);
	}
	@Test
	public void testDivide2()
	{
		int no1=10;
		int no2=2;
		int expected=5;
		int actual=aut.divide(no1, no2);
		//assertEquals(expected, actual);
		if(expected!=actual)
		{
			String message=String.format("Expected is %d, actual is %d", expected,actual);
			fail(message);
		}
	}
	
	@Test(timeout = 4000)
	public void testSpeed() throws InterruptedException
	{
		int no1=10;
		int no2=2;
		int expected=5;
		int actual=aut.divide(no1, no2);
	
		assertEquals(expected, actual);
		Thread.sleep(1000);	
	}
	
	@Test
	public void testStrings1()
	{
		String str1="hello";
		String str2="hello";
		assertSame(str1,str2);	//		is PASS

	}
	
	@Test
	public void testStrings2()
	{
		String str2=new String("hello");
		String str1=new String("hello");
		assertNotSame(str1,str2);		//references are different
	}
}
