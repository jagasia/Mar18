package jag;

import java.io.IOException;

public class Mathematics {
	int no1;
	int no2;
	int result;
	
	
	
	public int getNo1() {
		return no1;
	}
	public void setNo1(int no1) {
		this.no1 = no1;
	}
	public int getNo2() {
		return no2;
	}
	public void setNo2(int no2) {
		this.no2 = no2;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public void sum()
	{
		result=no1+no2;
	}
	public int sum(int i, int j)
	{
		return i+j;
	}
	
	public int difference(int i, int j)
	{
		return i-j;
	}
	
	public int product(int i, int j)
	{
		return i*j;
	}
	
	public int divide(int i, int j)
	{
		return i/j;
	}
}
