package jag;

public interface Admin {

}
