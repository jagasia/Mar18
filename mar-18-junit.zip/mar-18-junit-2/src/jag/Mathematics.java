package jag;

public class Mathematics {
	int no1;
	int no2;
	float result;
	
	public void sum()
	{
		result=no1+no2;
	}
	
	public void difference()
	{
		result=Math.abs(no1-no2);
	}
	
	public void product()
	{
		result=no1*no2;
	}
	
	public void divide()
	{
		result=(float)no1/no2;
	}
}
