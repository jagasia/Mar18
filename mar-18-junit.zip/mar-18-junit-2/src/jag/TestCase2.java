/**
 * 
 */
package jag;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

/**
 * @author rjaga
 *
 */
public class TestCase2 {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link jag.Mathematics#sum()}.
	 */
	@Test
	@Category(Admin.class)
	public void testSum() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link jag.Mathematics#difference()}.
	 */
	@Test
//	@Ignore
	
	public void testDifference() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link jag.Mathematics#product()}.
	 */
	@Test
	@Category(Admin.class)
	public void testProduct() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link jag.Mathematics#divide()}.
	 */
	@Test
	public void testDivide() {
		fail("Not yet implemented");
	}

}
