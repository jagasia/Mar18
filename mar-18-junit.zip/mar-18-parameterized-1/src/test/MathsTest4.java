package test;

import static org.junit.Assert.assertEquals;

import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

import jag.Mathematics;

@RunWith(Theories.class)
public class MathsTest4 {

	Mathematics aut=new Mathematics();
	@DataPoint
	public static int no1=2;
	@DataPoint
	public static int no2=3;
	@DataPoints
	public static int arr[]= {1,2,3};
	@Theory
	public void theory(int x, int y)
	{
		int expected=x+y;
//		if(expected==6)
//			expected++;
		System.out.println(x+":"+y+":"+expected);
		aut.setNo1(x);
		aut.setNo2(y);
		aut.sum();
		int actual=(int) aut.getResult();
		assertEquals(expected, actual);
		
	}
}